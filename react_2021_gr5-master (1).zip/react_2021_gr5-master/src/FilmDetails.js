import React from "react";

const FilmDetails = () => {
  return <h1>Szczegóły filmu</h1>;
};

export default FilmDetails;
